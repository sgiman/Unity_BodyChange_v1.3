﻿/*********************************************
 AnimControl_FM.cs

  Writing by Sergey Gasanov, may,2015 
  version: 1.1
*********************************************/
using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class AnimControl_FM : MonoBehaviour 
{
	public Animator animator;
	public Text NameAnim;
	public Text BtnPlayStop;
	
	private bool anim_flg = false;	 
	private string bname = "Stop";	 

	void Start () 
	{
		//animator = daz.GetComponent<Animator> ();
	}
	
	/****************************************
	 *              EXERCISES
	 ****************************************/
	public void SetExercise1 ()
	{
		animator.Play("Neuteral-T");
		NameAnim.text = "Neuteral T-pose";
		
	}
	public void SetExercise2 ()
	{
		animator.Play("NeckStretch");
		NameAnim.text = "Neck Stretch";
	}
	public void SetExercise3 ()
	{
		animator.Play("SmartSpine-006");
		NameAnim.text = "Smart Spine exercise-006";
	}
	public void SetExercise4 ()
	{
		animator.Play("ChairPose");
		NameAnim.text = "Chair Pose";
	}

	/****************************************
	 *                TESTS
	 ****************************************/
	public void SetTest1 ()
	{
		animator.Play("Female_M1_Idle_00(0)");
		NameAnim.text = "Female Idle (M1)";	
	}
	public void SetTest2 ()
	{
		animator.Play("Female_Stretch(0)");
		NameAnim.text = "Female Stretch";	
	}
	public void SetTest3 ()
	{
		animator.Play("Female_Hanging_Around");
		NameAnim.text = "Female Hanging_Around";	
	}
	public void SetTest4 ()
	{
		animator.Play("Curtsy_F(0)");
		NameAnim.text = "Curtsy Female";	
	}
	public void SetTest5 ()
	{
		animator.Play("Female_Causal-Talk_F 01");
		NameAnim.text = "Female Causal Talk";	
	}
	public void SetTest6 ()
	{
		animator.Play("Climb_to_Bed(0)");
		NameAnim.text = "Climb to Bed";	
	}
	public void SetTest7 ()
	{
		animator.Play("Idle_to_Kneel01(0)");
		NameAnim.text = "Knee";	
	}





	/*----------------------------
			   PlayStop
	----------------------------*/
	public void PlayStop () 
	{
		//AnimatorStateInfo stateInfo = animator.GetCurrentAnimatorStateInfo (0);
		
		// PLAY-STOP        
		if (anim_flg) { 
			bname = "Play";
			BtnPlayStop.text = "STOP";  
		} else {
			bname = "Stop";
			BtnPlayStop.text = "PLAY";  
		}
		
		// ANIMATION       
		if (anim_flg)
		{
			animator.speed = 1;
			anim_flg = false;
		}
		else
		{
			animator.speed = 0;
			anim_flg = true;
		}
		
		Debug.Log ("--> Animation: " + bname);
	}

}
