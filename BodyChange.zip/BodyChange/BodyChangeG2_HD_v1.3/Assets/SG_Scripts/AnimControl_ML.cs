﻿/*********************************************
 AnimControl_ML.cs

  Writing by Sergey Gasanov, may,2015 
  version: 1.1
*********************************************/
using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class AnimControl_ML : MonoBehaviour 
{
	//public GameObject daz; 
	public Animator animator;
	public Text NameAnim;
	public Text BtnPlayStop;

	private bool anim_flg = false;	 
	private string bname = "Stop";	 

	void Start () 
	{
		//animator = daz.GetComponent<Animator> ();
		//anim.SetBool ("Play", false);
		//animator.SetBool ("Neuteral_T", true);
		//animator.Play("ChairPose");
		//animator.Play("NeckStrech");
		//animator.Play("SmartSpine_N006");
		//animator.Play("Neuteral_T");

	}
	
	void FixedUpdate ()
	{
		//anim.SetBool ("Play", true);
	}

	/****************************************
	 *              EXERCISES
	 ****************************************/
	public void SetExercise1 ()
	{
		animator.Play("Neuteral-T");
		NameAnim.text = "Neuteral T-pose";

	}
	public void SetExercise2 ()
	{
		animator.Play("NeckStretch");
		NameAnim.text = "Neck Stretch";
	}
	public void SetExercise3 ()
	{
		animator.Play("SmartSpine-006");
		NameAnim.text = "Smart Spine exercise-006";
	}
	public void SetExercise4 ()
	{
		animator.Play("ChairPose");
		NameAnim.text = "Chair Pose";
	}
	public void SetExercise5 ()
	{
		animator.Play("neck_stretching");
		NameAnim.text = "Neck Stretching";
	}
	public void SetExercise6 ()
	{
		animator.Play("warrior_idle");
		NameAnim.text = "Warrior Pose";
	}
	public void SetExercise7 ()
	{
		animator.Play("arm_stretching");
		NameAnim.text = "Arm Stretching";	
	}

	/****************************************
	 *                SPORT
	 ****************************************/
	public void SetSport1 ()
	{
		animator.Play("golf_drive");
		NameAnim.text = "Golf Drive";	
	}
	public void SetSport2 ()
	{
		animator.Play("batter_on_deck");
		NameAnim.text = "Batter On Deck";	
	}

	/****************************************
	 *                TESTS
	 ****************************************/
	public void SetTest1 ()
	{
		animator.Play("male_idle_001");
		NameAnim.text = "male_idle_001";	
	}
	public void SetTest2 ()
	{
		animator.Play("male_003");
		NameAnim.text = "male_003";	
	}
	public void SetTest3 ()
	{
		animator.Play("male_005");
		NameAnim.text = "male_005";	
	}
	public void SetTest4 ()
	{
		animator.Play("male_006");
		NameAnim.text = "male_006";	
	}
	public void SetTest5 ()
	{
		animator.Play("male_007");
		NameAnim.text = "male_007";	
	}
	public void SetTest6 ()
	{
		animator.Play("male_008");
		NameAnim.text = "male_008";	
	}
	public void SetTest7 ()
	{
		animator.Play("male_009");
		NameAnim.text = "male_009";	
	}
	public void SetTest8 ()
	{
		animator.Play("male_010");
		NameAnim.text = "male_010";	
	}
	public void SetTest9 ()
	{
		animator.Play("male_011");
		NameAnim.text = "male_011";	
	}


	/*----------------------------
			   PlayStop
	----------------------------*/
	public void PlayStop () 
	{
		//AnimatorStateInfo stateInfo = animator.GetCurrentAnimatorStateInfo (0);
		
		// PLAY-STOP        
		if (anim_flg) { 
			bname = "Play";
			BtnPlayStop.text = "STOP";  
		} else {
			bname = "Stop";
			BtnPlayStop.text = "PLAY";  
		}

		// ANIMATION       
		if (anim_flg)
		{
			animator.speed = 1;
			anim_flg = false;
		}
		else
		{
			animator.speed = 0;
			anim_flg = true;
		}
		
		Debug.Log ("--> Animation: " + bname);
	}

}
