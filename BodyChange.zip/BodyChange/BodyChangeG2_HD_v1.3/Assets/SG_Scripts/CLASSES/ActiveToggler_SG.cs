﻿using UnityEngine;
using System.Collections;

public class ActiveToggler_SG : MonoBehaviour 
{

	public void ToggleActive () 
	{
		gameObject.SetActive (!gameObject.activeSelf);
	}

}
