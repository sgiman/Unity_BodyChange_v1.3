﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class HelpDisable: MonoBehaviour 
{
	public GameObject HelpPanel;

	public void SetHelpDisable ()
	{
		HelpPanel.SetActive (false);
	}
}
