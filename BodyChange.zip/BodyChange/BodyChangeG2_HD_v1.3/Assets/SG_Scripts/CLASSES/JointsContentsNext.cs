﻿using UnityEngine;
using System.Collections;

public class JointsContentsNext : MonoBehaviour 
{
	// JOINTS QUIZ-PANELS (NEXT)
	public GameObject JOINTS_C1;
	public GameObject JOINTS_C2;
	public GameObject JOINTS_C3;
	public GameObject JOINTS_C4;
	public GameObject JOINTS_C5;

	public void JointsConentsNext1() 
	{
		JOINTS_C1.SetActive(false);
		JOINTS_C2.SetActive(true);
		JOINTS_C3.SetActive(false);
		JOINTS_C4.SetActive(false);
		JOINTS_C5.SetActive(false);
	}

	public void JointsConentsNext2() 
	{
		JOINTS_C1.SetActive(false);
		JOINTS_C2.SetActive(false);
		JOINTS_C3.SetActive(true);
		JOINTS_C4.SetActive(false);
		JOINTS_C5.SetActive(false);
	}

	public void JointsConentsNext3() 
	{
		JOINTS_C1.SetActive(false);
		JOINTS_C2.SetActive(false);
		JOINTS_C3.SetActive(false);
		JOINTS_C4.SetActive(true);
		JOINTS_C5.SetActive(false);
	}

	public void JointsConentsNext4() 
	{
		JOINTS_C1.SetActive(false);
		JOINTS_C2.SetActive(false);
		JOINTS_C3.SetActive(false);
		JOINTS_C4.SetActive(false);
		JOINTS_C5.SetActive(true);
	}

	public void JointsConentsEnter() 
	{
		JOINTS_C1.SetActive(true);
		JOINTS_C2.SetActive(false);
		JOINTS_C3.SetActive(false);
		JOINTS_C4.SetActive(false);
		JOINTS_C5.SetActive(false);
	}
}
