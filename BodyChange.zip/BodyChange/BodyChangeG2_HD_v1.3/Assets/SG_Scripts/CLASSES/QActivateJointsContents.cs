﻿using UnityEngine;
using System.Collections;

public class QActivateJointsContents : MonoBehaviour {

	// QUIZ JOINTS for Buttom 1
	public GameObject PanelJOINTS;
	public GameObject JOINTS_001;
	public GameObject JOINTS_001_Content1;
	public GameObject JOINTS_001_Content2;
	public GameObject JOINTS_001_Content3;
	public GameObject JOINTS_001_Content4;
	public GameObject JOINTS_001_Content5;

	public void QuizJointsContents() 
	{
		PanelJOINTS.SetActive(false);
		JOINTS_001.SetActive(true);
		JOINTS_001_Content1.SetActive(true);
		JOINTS_001_Content2.SetActive(false);
		JOINTS_001_Content3.SetActive(false);
		JOINTS_001_Content4.SetActive(false);
		JOINTS_001_Content5.SetActive(false);
	}
}
