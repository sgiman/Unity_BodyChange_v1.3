﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class TogglerLibrary : MonoBehaviour 
{
	public GameObject LibraryExercises;
	public GameObject HelpPanel;
	
	public void ActivateToggleLibrary ()
	{
		LibraryExercises.SetActive (false);
		//HelpPanel.SetActive (true);
	}
}
