﻿using UnityEngine;
using System.Collections;

public class TogglerHelpQuiz : MonoBehaviour 
{
	// QUIZ PANELS
	public GameObject Q_HEAD;
	public GameObject Q_NECK;
	public GameObject Q_ABDOMEN;
	public GameObject Q_CHEST;
	public GameObject Q_PELVIS;
	public GameObject Q_SHOULDERS;
	public GameObject Q_HANDS;
	public GameObject Q_LEGS;
	public GameObject Q_JOINTS;
	//public GameObject HELP;

	public void ToggleActiveHelp () 
	{
		gameObject.SetActive (!gameObject.activeSelf);

		Q_HEAD.SetActive(false);
		Q_NECK.SetActive(false);
		Q_ABDOMEN.SetActive(false);
		Q_CHEST.SetActive(false);
		Q_PELVIS.SetActive(false);
		Q_SHOULDERS.SetActive(false);
		Q_HANDS.SetActive(false);
		Q_LEGS.SetActive(false);
		Q_JOINTS.SetActive(false);
		//HELP.SetActive(false);

	}

}
