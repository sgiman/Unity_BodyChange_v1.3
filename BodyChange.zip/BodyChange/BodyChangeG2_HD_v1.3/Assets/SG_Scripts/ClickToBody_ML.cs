﻿/*********************************************
 ClickToBody_ML.cs

  Writing by Sergey Gasanov, may,2015 
  version: 1.1
*********************************************/
using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class ClickToBody_ML: MonoBehaviour 
{
	public Text TextNamePartBody; 	// Name Body Parts
	public SkinnedMeshRenderer daz;	// DAZ Model
	
	// MATERIALS CHANGE
	public Material Glow;			
	public Material Red;	
	
	// QUIZ PANELS
	public GameObject Q_HEAD;
	public GameObject Q_NECK;
	public GameObject Q_ABDOMEN;
	public GameObject Q_CHEST;
	public GameObject Q_PELVIS;
	public GameObject Q_SHOULDERS;
	public GameObject Q_HANDS;
	public GameObject Q_LEGS;
	public GameObject Q_JOINTS;
	public GameObject HELP;
	public GameObject QUIZ;

	// QUIZ JOINTS for Buttom 1
	public GameObject JOINTS_001;
	public GameObject JOINTS_001_Content1;
	public GameObject JOINTS_001_Content2;
	public GameObject JOINTS_001_Content3;
	public GameObject JOINTS_001_Content4;
	public GameObject JOINTS_001_Content5;
	
	public GameObject JOINTS_002;
	public GameObject JOINTS_003;
	public GameObject JOINTS_004;
	public GameObject JOINTS_005;
	public GameObject JOINTS_006;
	public GameObject JOINTS_007;
	public GameObject JOINTS_008;
	public GameObject JOINTS_009;
	public GameObject JOINTS_010;
	public GameObject JOINTS_011;
	public GameObject JOINTS_012;
	public GameObject JOINTS_013;
	public GameObject JOINTS_014;
	
	static string PartName;		    // Name body part
	private string ntemp = ""; 
	private Material[] CasheMat; 
	private Material[] TempMat; 
	static bool sel; 
	
	void Start ()
	{
		CasheMat = daz.materials;
		sel = false;
	}
	
	/*=======================
		OnMouseEnter
	========================*/
	void OnMouseEnter ()
	{
		if (!sel) 
		{
			PartName = this.gameObject.name;
			TextNamePartBody.text = PartName;
			
			// If no rotate (orbit)
			if (!Input.GetMouseButton (1)) {
				int ind = FindIndexMat (PartName);
				ChangeMat (ind);
			}
			
			//Debug.Log ("\nENTER - " + PartName);
		}
	}
	
	/*=======================
		OnMouseExit
	========================*/
	void OnMouseExit ()
	{
		if (!sel) 
		{
			RestoreMat ();
			TextNamePartBody.text = ntemp;
			//Debug.Log ("\nEXIT - " + PartName);
		}
	}
	
	/**********************************
		   OnMouseDowm (Select)
	***********************************/
	void OnMouseDown ()
	{
		if (!sel) 
		{
			sel = true;
			PartName = this.gameObject.name;
			TextNamePartBody.text = PartName;
			int ind = FindIndexMat (PartName);
			ChangeMat (ind);
			INQUIRER (PartName); 
		} else 
		{
			sel = false;
			daz.materials = CasheMat;
			QUIZ_PANEL_ALL_OFF ();
		}
	}
	
	/**********************************
		      INQUIRER (Menu)
	***********************************/
	void INQUIRER (string name)
	{
		//string InqName = "INQUIRER -->" + name;
		string InqName = name;
		TextNamePartBody.text = InqName;
		QUIZ_PANEL_ON (name);
		Debug.Log ("INQUIRER -->" + InqName);
		
	}
	
	
	/*------------------------
		QUIZ_PANEL_ON
	------------------------*/
	void QUIZ_PANEL_ON (string body_name)
	{
		switch (body_name)
		{
		case "HEAD":
			Q_HEAD.SetActive(true);
			Q_NECK.SetActive(false);
			Q_ABDOMEN.SetActive(false);
			Q_CHEST.SetActive(false);
			Q_PELVIS.SetActive(false);
			Q_SHOULDERS.SetActive(false);
			Q_HANDS.SetActive(false);
			Q_LEGS.SetActive(false);
			Q_JOINTS.SetActive(false);
			HELP.SetActive(false);
			QUIZ.SetActive(true);
			JOINTS_001_Contents_OFF ();
			break;
			
		case "NECK":
			Q_HEAD.SetActive(false);
			Q_NECK.SetActive(true);
			Q_ABDOMEN.SetActive(false);
			Q_CHEST.SetActive(false);
			Q_PELVIS.SetActive(false);
			Q_SHOULDERS.SetActive(false);
			Q_HANDS.SetActive(false);
			Q_LEGS.SetActive(false);
			Q_JOINTS.SetActive(false);
			HELP.SetActive(false);
			QUIZ.SetActive(true);
			JOINTS_001_Contents_OFF ();
			break;
			
		case "ABDOMEN":
			Q_HEAD.SetActive(false);
			Q_NECK.SetActive(false);
			Q_ABDOMEN.SetActive(true);
			Q_CHEST.SetActive(false);
			Q_PELVIS.SetActive(false);
			Q_SHOULDERS.SetActive(false);
			Q_HANDS.SetActive(false);
			Q_LEGS.SetActive(false);
			Q_JOINTS.SetActive(false);
			HELP.SetActive(false);
			QUIZ.SetActive(true);
			JOINTS_001_Contents_OFF ();
			break;
			
		case "CHEST":
			Q_HEAD.SetActive(false);
			Q_NECK.SetActive(false);
			Q_ABDOMEN.SetActive(false);
			Q_CHEST.SetActive(true);
			Q_PELVIS.SetActive(false);
			Q_SHOULDERS.SetActive(false);
			Q_HANDS.SetActive(false);
			Q_LEGS.SetActive(false);
			Q_JOINTS.SetActive(false);
			HELP.SetActive(false);
			QUIZ.SetActive(true);
			JOINTS_001_Contents_OFF ();
			break;
			
		case "PELVIS":
			Q_HEAD.SetActive(false);
			Q_NECK.SetActive(false);
			Q_ABDOMEN.SetActive(false);
			Q_CHEST.SetActive(false);
			Q_PELVIS.SetActive(true);
			Q_SHOULDERS.SetActive(false);
			Q_HANDS.SetActive(false);
			Q_LEGS.SetActive(false);
			Q_JOINTS.SetActive(false);
			HELP.SetActive(false);
			QUIZ.SetActive(true);
			JOINTS_001_Contents_OFF ();
			break;
			
			
		case "RIGHT FOREARM":
		case "LEFT FOREARM":
		case "LEFT SHOULDER":
		case "RIGHT SHOULDER":
		case "RIGHT HAND":
		case "LEFT HAND":
			Q_HEAD.SetActive(false);
			Q_NECK.SetActive(false);
			Q_ABDOMEN.SetActive(false);
			Q_CHEST.SetActive(false);
			Q_PELVIS.SetActive(false);
			Q_SHOULDERS.SetActive(false);
			Q_HANDS.SetActive(true);
			Q_LEGS.SetActive(false);
			Q_JOINTS.SetActive(false);
			HELP.SetActive(false);
			QUIZ.SetActive(true);
			JOINTS_001_Contents_OFF ();
			break;
			
			
		case "LEFT SHIN":
		case "RIGHT SHIN":
		case "LEFT THIGH":
		case "RIGHT THIGH":
		case "LEFT FOOT":
		case "RIGHT FOOT":
			Q_HEAD.SetActive(false);
			Q_NECK.SetActive(false);
			Q_ABDOMEN.SetActive(false);
			Q_CHEST.SetActive(false);
			Q_PELVIS.SetActive(false);
			Q_SHOULDERS.SetActive(false);
			Q_HANDS.SetActive(false);
			Q_LEGS.SetActive(true);
			Q_JOINTS.SetActive(false);
			HELP.SetActive(false);
			QUIZ.SetActive(true);
			JOINTS_001_Contents_OFF ();
			break;
			
			
		case "RIGHT WRIST":
		case "LEFT WRIST":
		case "LEFT SHOULDER JOINT":
		case "RIGHT SHOULDER JOINT":
		case "LEFT ELBOW JOINT":
		case "RIGHT ELBOW JOINT":
		case "LEFT KNEE JOINT":
		case "RIGHT KNEE JOINT":
			Q_HEAD.SetActive(false);
			Q_NECK.SetActive(false);
			Q_ABDOMEN.SetActive(false);
			Q_CHEST.SetActive(false);
			Q_PELVIS.SetActive(false);
			Q_SHOULDERS.SetActive(false);
			Q_HANDS.SetActive(false);
			Q_LEGS.SetActive(false);
			Q_JOINTS.SetActive(true);
			HELP.SetActive(false);
			QUIZ.SetActive(true);
			JOINTS_001_Contents_OFF ();
			break;
			
		default:
			break;
		}
		
	}
	
	/*------------------------
		QUIZ_PANEL_ALL_OFF
	------------------------*/
	void QUIZ_PANEL_ALL_OFF ()
	{
		Q_HEAD.SetActive(false);
		Q_NECK.SetActive(false);
		Q_ABDOMEN.SetActive(false);
		Q_CHEST.SetActive(false);
		Q_PELVIS.SetActive(false);
		Q_SHOULDERS.SetActive(false);
		Q_HANDS.SetActive(false);
		Q_LEGS.SetActive(false);
		Q_JOINTS.SetActive(false);
		
		JOINTS_001_Contents_OFF ();
		
		JOINTS_002.SetActive(false);
		JOINTS_003.SetActive(false);
		JOINTS_004.SetActive(false);
		JOINTS_005.SetActive(false);
		JOINTS_006.SetActive(false);
		JOINTS_007.SetActive(false);
		JOINTS_008.SetActive(false);
		JOINTS_009.SetActive(false);
		JOINTS_010.SetActive(false);
		JOINTS_011.SetActive(false);
		JOINTS_012.SetActive(false);
		JOINTS_013.SetActive(false);
		JOINTS_014.SetActive(false);
		
	}
	
	
	/*----------------------------
		JOINTS_001_Contents_OFF
	-----------------------------*/
	public void JOINTS_001_Contents_OFF ()
	{
		JOINTS_001.SetActive(false);
		JOINTS_001_Content1.SetActive(true);
		JOINTS_001_Content2.SetActive(false);
		JOINTS_001_Content3.SetActive(false);
		JOINTS_001_Content4.SetActive(false);
		JOINTS_001_Content5.SetActive(false);
	}
	
	
	/*------------------------
		    ChangeMat
	------------------------*/
	void ChangeMat (int i)
	{	
		// Material[] mats = new Material[] { Red, Glow, Glow, Red, Glow, Red, Glow, Red, Glow, Red, Glow, Red };
		TempMat = daz.materials;
		TempMat [i] = Glow;
		
		if (i == 16) // if select HEAD  
		{
			TempMat [20] = Glow;
			TempMat [21] = Glow;
		}
		
		daz.materials = TempMat;
	}
	
	/*------------------------
		    RestoreMat
	------------------------*/
	void RestoreMat ()
	{	
		daz.materials = CasheMat;
	}
	
	/*------------------------
           FindIndexMat
	------------------------*/
	int FindIndexMat (string name)
	{
		int index = 0;
		
		switch (name)
		{
			
		case "HEAD":
			index = 16; // and 7 - Head Back, 23 - Ears, 10 - Lips
			break;

		case "NECK":
			index = 28;
			break;
			
		case "ABDOMEN":
			index = 30;
			break;
			
		case "CHEST":
			index = 31;
			break;
			
		case "PELVIS":
			index = 29;
			break;
			
		case "RIGHT SHOULDER":
			index = 27;
			break;
			
		case "LEFT SHOULDER":
			index = 25;
			break;
			
		case "RIGHT SHOULDER JOINT":
			index = 26;
			break;
			
		case "LEFT SHOULDER JOINT":
			index = 24;
			break;
			
		case "RIGHT FOREARM":
			index = 37;
			break;
			
		case "LEFT FOREARM":
			index = 34;
			break;
			
		case "LEFT ELBOW JOINT":
			index = 33;
			break;
			
		case "RIGHT ELBOW JOINT":
			index = 36;
			break;
			
		case "RIGHT WRIST":
			index = 35;
			break;
			
		case "LEFT WRIST":
			index = 32;
			break;
			
		case "RIGHT HAND":
			index = 23;
			break;
			
		case "LEFT HAND":
			index = 22;
			break;
			
		case "LEFT SHIN":
			index = 0;
			break;
			
		case "RIGHT SHIN":
			index = 3;
			break;
			
		case "LEFT KNEE JOINT":
			index = 2;
			break;
			
		case "RIGHT KNEE JOINT":
			index = 5;
			break;
			
		case "LEFT THIGH":
			index = 1;
			break;
			
		case "RIGHT THIGH":
			index = 4;
			break;
			
		case "LEFT FOOT":
			index = 38;
			break;
			
		case "RIGHT FOOT":
			index = 39;
			break;
			
		default:
			break;
		}
		
		return index;
	}
}

/************************************************************** 

-----------------------------
	     COLLIDERS:
-----------------------------
HEAD
NECK
ABDOMEN
CHEST
PELVIS
RIGHT SHOULDER
LEFT SHOULDER
RIGHT SHOULDER JOINT
LEFT SHOULDER JOINT
RIGHT FOREARM
LEFT FOREARM
LEFT ELBOW JOINT
RIGHT ELBOW JOINT
RIGHT WRIST
LEFT WRIST
RIGHT HAND
LEFT HAND
LEFT SHIN
RIGHT SHIN
LEFT KNEE JOINT
RIGHT KNEE JOINT
LEFT THIGH
RIGHT THIGH
LEFT FOOT
RIGHT FOOT

*************************************************************/
