﻿//**********************************************************
//  FPSCount.cs 
//**********************************************************
// Writing by sgiman may-2015

using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class FPS_Count : MonoBehaviour {

	public Text FPScount; 
	private double fps;

	void Update () 
	{

		fps = 1.0 / Time.smoothDeltaTime;
		FPScount.text = fps.ToString();
		//FPScount.text = "ABC";

	}
}
