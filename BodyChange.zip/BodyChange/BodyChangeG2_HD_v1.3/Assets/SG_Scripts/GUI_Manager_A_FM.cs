﻿/*********************************************
  GUI_Manager_A_FM.cs

  Writing by Sergey Gasanov, may,2015 
  version: 1.0
*********************************************/
using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class GUI_Manager_A_FM : MonoBehaviour 
{
	public Slider offsetSliderVert;	// Slider offset Vert
	public Slider offsetSliderHor;	// Slider offset Hor
	public Camera cam; 				// Main Camera
	public GameObject MainSliders_FM; 
	public GameObject PanelHelp; 
	public GameObject PanelLibrary; 

	void Start ()
	{
		cam.GetComponent<MOrbit_SG>().nx = 180.0f;
		cam.GetComponent<MOrbit_SG>().ny = 3.0f;
		cam.GetComponent<MOrbit_SG>().nz = 3.6f;
	}

	// MALE
	public void LOAD_EXERCISES_ML()
	{
		Application.LoadLevel("EXERCISES_ML");
	}

	// QUIZ
	public void LOAD_QUIZ_FM()
	{
		Application.LoadLevel("QUIZ_FM");

	}

	/*----------------------------
			  FullScreen
	----------------------------*/
	public void FullScreen()
	{
		Screen.fullScreen = !Screen.fullScreen; 
		Debug.Log ("FULL SCREEN... ");
	}
	
	/*----------------------------
				Exit
	----------------------------*/
	public void Exit ()
	{
		Application.Quit(); 
		Debug.Log ("EXIT... ");
	}


	/*------------------ UpdateOffsetSliderVert ----------------------*/
	public void UpdateOffsetSliderVert()
	{
		cam.GetComponent<MOrbit_SG>().offset.y = offsetSliderVert.value;
	}
	
	/*------------------ UpdateOffsetSliderHor ----------------------*/
	public void UpdateOffsetSliderHor()
	{
		cam.GetComponent<MOrbit_SG>().offset.x = offsetSliderHor.value;
	}
	
	/*==================================================================
	                          CONTROLE
	==================================================================*/
	public void ResetCamera ()
	{
		cam.GetComponent<MOrbit_SG> ().offset.y = 0;
		cam.GetComponent<MOrbit_SG> ().offset.x = 0;
		offsetSliderVert.value = 0;
		offsetSliderHor.value = 0;
	}
	
	/*------------------ ToggleMorphSlidersAnim ----------------------*/
	public void ToggleMorphSliders ()
	{
		if (this.GetComponent<MainSliders_FM> ().enabled) 
		{
			this.GetComponent<MorphSliders_FM> ().enabled = true;
			this.GetComponent<MainSliders_FM> ().enabled = false;
			MainSliders_FM.SetActive (false);
		} 
		else 
		{
			this.GetComponent<MorphSliders_FM> ().enabled = false;
			this.GetComponent<MainSliders_FM> ().enabled = true;
			MainSliders_FM.SetActive (true);
		}
	}

	/*------------------ TogglePanelHelp ----------------------*/
	public void ToggleHelpLibrary ()
	{
		PanelHelp.SetActive (!PanelHelp.activeSelf);
		PanelLibrary.SetActive (false);
	}

	/*------------------ ToggleLibrary ----------------------*/
	public void ToggleLibrary ()
	{
		PanelLibrary.SetActive (!PanelLibrary.activeSelf);
		PanelHelp.SetActive (false);
	}

}

