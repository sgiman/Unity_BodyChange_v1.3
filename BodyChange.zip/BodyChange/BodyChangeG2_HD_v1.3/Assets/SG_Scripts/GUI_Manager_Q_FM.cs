﻿/*********************************************
  GUI_Manager_Q_FM.cs

  Writing by Sergey Gasanov, may,2015 
  version: 1.0
*********************************************/
using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class GUI_Manager_Q_FM : MonoBehaviour 
{
	public Slider offsetSliderVert;	// Slider offset Vert
	public Slider offsetSliderHor;	// Slider offset Hor
	public Camera cam; 				// Main Camera
	public GameObject COLLIDERS; 
	public GameObject MainBodySliders; 

	void Start ()
	{
		cam.GetComponent<MOrbit_SG>().nx = 180.0f;
		cam.GetComponent<MOrbit_SG>().ny = 3.0f;
		cam.GetComponent<MOrbit_SG>().nz = 3.6f;
		COLLIDERS.SetActive (true); // Enable Selection
	}
	
	// EXERCISES
	public void LOAD_EXERCISES_FM()
	{
		Application.LoadLevel("EXERCISES_FM");
	}
	
	// MALE
	public void LOAD_QUIZ_ML()
	{
		Application.LoadLevel("QUIZ_ML");
	}

	/*----------------------------
			  FullScreen
	----------------------------*/
	public void FullScreen()
	{
		Screen.fullScreen = !Screen.fullScreen; 
		Debug.Log ("FULL SCREEN... ");
	}
	
	/*----------------------------
				Exit
	----------------------------*/
	public void Exit ()
	{
		Application.Quit(); 
		Debug.Log ("EXIT... ");
	}

	/*------------------ UpdateOffsetSliderVert ----------------------*/
	public void UpdateOffsetSliderVert()
	{
		cam.GetComponent<MOrbit_SG>().offset.y = offsetSliderVert.value;
	}
	
	/*------------------ UpdateOffsetSliderHor ----------------------*/
	public void UpdateOffsetSliderHor()
	{
		cam.GetComponent<MOrbit_SG>().offset.x = offsetSliderHor.value;
	}
	
	/*==================================================================
    	                           CONTROL
	==================================================================*/
	public void ResetCamera ()
	{
		cam.GetComponent<MOrbit_SG> ().offset.y = 0;
		cam.GetComponent<MOrbit_SG> ().offset.x = 0;
		offsetSliderVert.value = 0;
		offsetSliderHor.value = 0;
	}
	
	/*------------------ ToggleMorphSliders ----------------------*/
	public void ToggleMorphSliders ()
	{
		if (this.GetComponent<MorphSliders_FM> ().enabled) 
		{
			this.GetComponent<MorphSliders_FM> ().enabled = false;
			this.GetComponent<MainSliders_FM> ().enabled = true;
			MainBodySliders.SetActive (true);
		} 
		else 
		{
			this.GetComponent<MorphSliders_FM> ().enabled = true;
			this.GetComponent<MainSliders_FM> ().enabled = false;
			MainBodySliders.SetActive (false);
		}
	}

}

