﻿/*********************************************
  GUI_Manager_Q_ML.cs

  Writing by Sergey Gasanov, may,2015 
  version: 1.0
*********************************************/
using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class GUI_Manager_Q_ML : MonoBehaviour 
{
	public Slider offsetSliderVert;	// Slider offset Vert
	public Slider offsetSliderHor;	// Slider offset Hor
	public Camera cam; 				// Main Camera
	public GameObject COLLIDERS; 
	public GameObject MainBodySliders; 

	void Start ()
	{
		cam.GetComponent<MOrbit_SG>().nx = 180.0f;
		cam.GetComponent<MOrbit_SG>().ny = 5.0f;
		cam.GetComponent<MOrbit_SG>().nz = 2.13f;
		COLLIDERS.SetActive (true); // Enable Selection
	}

	// EXERCISES
	public void LOAD_EXERCISES_ML()
	{
		Application.LoadLevel("EXERCISES_ML");
	}

	// FEMALE
	public void LOAD_QUIZ_FM()
	{
		Application.LoadLevel("QUIZ_FM");
	}

	/*----------------------------
			  FullScreen
	----------------------------*/
	public void FullScreen()
	{
		Screen.fullScreen = !Screen.fullScreen; 
		Debug.Log ("FULL SCREEN... ");
	}
	
	/*----------------------------
				Exit
	----------------------------*/
	public void Exit ()
	{
		Application.Quit(); 
		Debug.Log ("EXIT... ");
	}

	/*------------------ UpdateOffsetSliderVert ----------------------*/
	public void UpdateOffsetSliderVert()
	{
		cam.GetComponent<MOrbit_SG>().offset.y = offsetSliderVert.value;
	}

	/*------------------ UpdateOffsetSliderHor ----------------------*/
	public void UpdateOffsetSliderHor()
	{
		cam.GetComponent<MOrbit_SG>().offset.x = offsetSliderHor.value;
	}

	/*==================================================================
	                          CONTROLE
	==================================================================*/
	public void ResetCamera ()
	{
		cam.GetComponent<MOrbit_SG> ().offset.y = 0;
		cam.GetComponent<MOrbit_SG> ().offset.x = 0;
		offsetSliderVert.value = 0;
		offsetSliderHor.value = 0;
	}

	/*------------------ ToggleMorphSliders ----------------------*/
	public void ToggleMorphSliders ()
	{
		if (this.GetComponent<MorphSliders_ML> ().enabled) 
		{
			this.GetComponent<MorphSliders_ML> ().enabled = false;
			this.GetComponent<MainSliders_ML> ().enabled = true;
			MainBodySliders.SetActive (true);
		} 
		else 
		{
			this.GetComponent<MorphSliders_ML> ().enabled = true;
			this.GetComponent<MainSliders_ML> ().enabled = false;
			MainBodySliders.SetActive (false);
		}
	}
}
