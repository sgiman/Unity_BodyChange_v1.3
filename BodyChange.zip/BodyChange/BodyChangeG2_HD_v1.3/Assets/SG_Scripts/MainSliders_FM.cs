﻿/*********************************************
  MainSliders_FM.cs

  Writing by Sergey Gasanov, may,2015 
  version: 1.1
*********************************************/
using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class MainSliders_FM : MonoBehaviour {

	public GameObject daz; 

	public Slider Weight;	 		// 7
	public Slider BodySize;			// 70
	public Slider Thin;				// 62
	public Slider Emaciated;		// 68
	public Slider PearFigure;		// 63
	public Slider Voloptuos;		// 61
	public Slider BellyFat;			// 27
	public Slider WaistWait;		// 37
	public Slider AbdomenLength;	// 25
	public Slider ArmLength;		// 6
	public Slider Vicroria4;		// 0
	public Slider Vicroria6;		// 10
	public Slider BodyBuilderSize;	// 71
	public Slider BreastsGone;		// 57 
	public Slider FaceAge;			// 29	

	public Text T_Weight;	 		
	public Text T_BodySize;
	public Text T_Thin;
	public Text T_Emaciated;
	public Text T_PearFigure;
	public Text T_Voloptuos;
	public Text T_BellyFat;
	public Text T_WaistWait;
	public Text T_AbdomenLength;
	public Text T_ArmLength;
	public Text T_Vicroria4;
	public Text T_Vicroria6;
	public Text T_BodyBuilderSize;
	public Text T_BreastsGone; 
	public Text T_FaceAge;	


	void Update () 
	{
		int val;
		MegaMorph mr = daz.GetComponent<MegaMorph> ();
		
		val = (int)mr.GetPercent (7);
		T_Weight.text = val.ToString ();	 	

		val = (int)mr.GetPercent (70);
		T_BodySize.text = val.ToString ();	 	

		val = (int)mr.GetPercent (62);
		T_Thin.text = val.ToString ();	 	

		val = (int)mr.GetPercent (68);
		T_Emaciated.text = val.ToString ();	 	

		val = (int)mr.GetPercent (63);
		T_PearFigure.text = val.ToString ();	 	

		val = (int)mr.GetPercent (61);
		T_Voloptuos.text = val.ToString ();	 	

		val = (int)mr.GetPercent (27);
		T_BellyFat.text = val.ToString ();	 	

		val = (int)mr.GetPercent (37);
		T_WaistWait.text = val.ToString ();	 	

		val = (int)mr.GetPercent (25);
		T_AbdomenLength.text = val.ToString ();	 	

		val = (int)mr.GetPercent (6);
		T_ArmLength.text = val.ToString ();	 	

		val = (int)mr.GetPercent (0);
		T_Vicroria4.text = val.ToString ();	 	

		val = (int)mr.GetPercent (10);
		T_Vicroria6.text = val.ToString ();	 	

		val = (int)mr.GetPercent (71);
		T_BodyBuilderSize.text = val.ToString ();	 	

		val = (int)mr.GetPercent (57);
		T_BreastsGone.text = val.ToString ();	 	

		val = (int)mr.GetPercent (29);
		T_FaceAge.text = val.ToString ();	 	

	}


	/*----------------------------
			SetMainSliders
	----------------------------*/
	public void  SetMainSliders()
	{
		// Num & Array names morphs channels  
		MegaMorph mr = daz.GetComponent<MegaMorph>();
		int num = mr.NumChannels();
		string[] names = new string[num];
		names = mr.GetChannelNames(); 

		mr.SetPercent (7, Weight.value);
		mr.SetPercent (70, BodySize.value);
		mr.SetPercent (62, Thin.value);
		mr.SetPercent (68, Emaciated.value);
		mr.SetPercent (63, PearFigure.value);
		mr.SetPercent (61, Voloptuos.value);
		mr.SetPercent (27, BellyFat.value);
		mr.SetPercent (37, WaistWait.value);
		mr.SetPercent (25, AbdomenLength.value);
		mr.SetPercent (6, ArmLength.value);
		mr.SetPercent (0, Vicroria4.value);
		mr.SetPercent (10, Vicroria6.value);
		mr.SetPercent (71, BodyBuilderSize.value);
		mr.SetPercent (57, BreastsGone.value); 
		mr.SetPercent (29, FaceAge.value);	

	}

	/*----------------------------
			ResetMainSliders
	----------------------------*/
	public void ResetMainSliders () 
	{
		// Num & Array names morphs channels  
		MegaMorph mr = daz.GetComponent<MegaMorph> ();
		int num = mr.NumChannels ();
		string[] names = new string[num];
		names = mr.GetChannelNames (); 
			
		for (int i=0; i<num; i++) 
		{
			mr.SetPercent (i, 0);
		}

		Weight.value = 0;
		BodySize.value = 0;
		Thin.value = 0;
		Emaciated.value = 0;
		PearFigure.value = 0;
		Voloptuos.value = 0;
		BellyFat.value = 0;
		WaistWait.value = 0;
		AbdomenLength.value = 0;
		ArmLength.value = 0;
		Vicroria4.value = 0;
		Vicroria6.value = 0;
		BodyBuilderSize.value = 0;
		BreastsGone.value = 0; 
		FaceAge.value = 0;	
	
	}

}


