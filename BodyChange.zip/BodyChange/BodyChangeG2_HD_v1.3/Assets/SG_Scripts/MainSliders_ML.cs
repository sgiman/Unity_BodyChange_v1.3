﻿/*********************************************
  MainSliders_ML.cs

  Writing by Sergey Gasanov, may,2015 
  version: 1.1
*********************************************/
using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class MainSliders_ML : MonoBehaviour {
	public GameObject daz;		

	public Slider Weight;	 		// 5
	public Slider Heavy;			// 82
	public Slider Thin;				// 78
	public Slider Stocky;			// 79
	public Slider Portly;			// 80
	public Slider Emaciated;		// 85
	public Slider Androgynous;		// 89
	public Slider Bodybuilder;		// 7
	public Slider GenMale;			// 49
	public Slider Height;			// 81
	public Slider Fitness;			// 6 
	public Slider FitnessSize;		// 83
	public Slider BodybuilderSize;	// 87
	public Slider BellySize;		// 33
	public Slider FaceAge; 			// 47

	public Text T_Weight;	 		
	public Text T_Heavy;			
	public Text T_Thin;				
	public Text T_Stocky;			
	public Text T_Portly;		
	public Text T_Emaciated;	
	public Text T_Androgynous;	
	public Text T_Bodybuilder;	
	public Text T_GenMale;		
	public Text T_Height;		
	public Text T_Fitness;			 
	public Text T_FitnessSize;		
	public Text T_BodybuilderSize;	
	public Text T_BellySize;		
	public Text T_FaceAge; 			

	void Update () 
	{
		int val;
		MegaMorph mr = daz.GetComponent<MegaMorph> ();

		val = (int)mr.GetPercent (5);
		T_Weight.text = val.ToString ();	 	// 5

		val = (int)mr.GetPercent (82);
		T_Heavy.text = val.ToString ();			// 82

		val = (int)mr.GetPercent (78);
		T_Thin.text = val.ToString ();			// 78

		val = (int)mr.GetPercent (79);
		T_Stocky.text = val.ToString ();		// 79

		val = (int)mr.GetPercent (80);
		T_Portly.text = val.ToString ();		// 80

		val = (int)mr.GetPercent (85);
		T_Emaciated.text = val.ToString ();		// 85

		val = (int)mr.GetPercent (89);
		T_Androgynous.text = val.ToString ();	// 89

		val = (int)mr.GetPercent (7);
		T_Bodybuilder.text = val.ToString ();	// 7

		val = (int)mr.GetPercent (49);
		T_GenMale.text = val.ToString ();		// 49

		val = (int)mr.GetPercent (81);
		T_Height.text = val.ToString ();		// 81

		val = (int)mr.GetPercent (6);
		T_Fitness.text = val.ToString ();		// 6 

		val = (int)mr.GetPercent (83);
		T_FitnessSize.text = val.ToString ();	// 83

		val = (int)mr.GetPercent (87);
		T_BodybuilderSize.text = val.ToString ();	// 87

		val = (int)mr.GetPercent (33);
		T_BellySize.text = val.ToString ();		// 33

		val = (int)mr.GetPercent (47);
		T_FaceAge.text = val.ToString ();		// 47

	}


	/*----------------------------
			SetMainSliders
	----------------------------*/
	public void  SetMainSliders()
	{
		// Num & Array names morphs channels  
		MegaMorph mr = daz.GetComponent<MegaMorph>();
		int num = mr.NumChannels();
		string[] names = new string[num];
		names = mr.GetChannelNames(); 

		mr.SetPercent (5,  Weight.value);	 		// 5
		mr.SetPercent (82, Heavy.value);			// 82
		mr.SetPercent (78, Thin.value);				// 78
		mr.SetPercent (79, Stocky.value);			// 79
		mr.SetPercent (80, Portly.value);			// 80
		mr.SetPercent (85, Emaciated.value);		// 85
		mr.SetPercent (89, Androgynous.value);		// 89
		mr.SetPercent (7,  Bodybuilder.value);		// 7
		mr.SetPercent (49, GenMale.value);			// 49
		mr.SetPercent (81, Height.value);			// 81
		mr.SetPercent (6,  Fitness.value);			// 6 
		mr.SetPercent (83, FitnessSize.value);		// 83
		mr.SetPercent (87, BodybuilderSize.value);	// 87
		mr.SetPercent (33, BellySize.value);		// 33
		mr.SetPercent (47, FaceAge.value);			// 47

	}


	/*----------------------------
			ResetMainSliders
	----------------------------*/
	public void ResetMainSliders () 
	{
		// Num & Array names morphs channels  
		MegaMorph mr = daz.GetComponent<MegaMorph> ();
		int num = mr.NumChannels ();
		string[] names = new string[num];
		names = mr.GetChannelNames (); 
			
		for (int i=0; i<num; i++) 
		{
			mr.SetPercent (i, 0);
		}

		Weight.value = 0;	 		// 5
		Heavy.value = 0;			// 82
		Thin.value = 0;				// 78
		Stocky.value = 0;			// 79
		Portly.value = 0;			// 80
		Emaciated.value = 0;		// 85
		Androgynous.value = 0;		// 89
		Bodybuilder.value = 0;		// 7
		GenMale.value = 0;			// 49
		Height.value = 0;			// 81
		Fitness.value = 0;			// 6 
		FitnessSize.value = 0;		// 83
		BodybuilderSize.value = 0;	// 87
		BellySize.value = 0;		// 33
		FaceAge.value = 0;			// 47

	}

}


