﻿/*********************************************
  MorphSliders_FM.cs

  FEMALE
  
  Writing by Sergey Gasanov, may,2015 
  version: 1.0
*********************************************/
using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class MorphSliders_FM : MonoBehaviour {

	public GameObject daz; 
	public int xPos = 25;
	public int yPos = 25;
	public int wide = 100;

	public Vector2 scrollPosition; 	// Position of the scrollview
	public GUISkin guiSkin;

	public GUIStyle labelStyle1; 	// Label Style for names morph channels
	public GUIStyle labelStyle2; 	// Label Style for NAME CATEOGORY
	public GUIStyle labelStyle3; 	// Label Style for SPACE LAGE

	//public Slider offsetSliderVert;	// Slider offset Vert
	//public Slider offsetSliderHor;	// Slider offset Hor
	//public Camera cam; 				// Main Camera

	private float[] sliderValues;


	/*----------------------------------- Category Channels ---------------------------------------*/
	// Category 1 - EVOLUTION
	private int[] cat1 = { 7, 8, 9, 61, 62, 63, 64, 65, 66, 67, 68, 70, 71, 72, 77 }; 				
	
	// Category 2 - VICTORIA
	private int[] cat2 = { 10, 0, 36, 35, 11 }; 				

	// Category 3 - BODY
	private int[] cat3 = { 1, 4, 5, 21, 22, 23, 32, 39, 44, 45, 69  }; 

	// Category 4 - ABDOMEN
	private int[] cat4 = { 12, 13, 14, 15, 16, 17, 25, 26, 27, 37}; 

	// Category 5 - HIP
	private int[] cat5 = { 19, 20, 31, 33, 34, 46, 49, 50, 51, 52, 53 }; 

	// Category 6 - HANDS
	private int[] cat6 = { 2, 3, 18, 24, 38, 42, 54, 76 }; 

	// Category 7 - LEGS
	private int[] cat7 = { 6, 30, 40, 41, 43, 48, 49 }; 

	// Category 8 - FACE
	private int[] cat8 = { 28, 29 };

	// Category 9 - BREAST
	private int[] cat9 = { 55, 56, 57, 58, 59, 60, 73, 74, 75 };

	void Awake () 
	{
		MegaMorph mr = daz.GetComponent<MegaMorph>();
		int num = mr.NumChannels();
		sliderValues = new float[num];
	}

	/*=========== GUI ==========*/
	void  OnGUI ()
	{
		int i;

		GUI.skin = guiSkin; 	

		//GUI.Label (new Rect (10, 10, 100, 20), "Hello World!");

		GUILayout.BeginArea( new Rect(xPos, yPos, wide, Screen.height - 2*yPos));
		scrollPosition = GUILayout.BeginScrollView(scrollPosition);
		
		// Num & Array names morphs channels  
		MegaMorph mr = daz.GetComponent<MegaMorph>();
		int num = mr.NumChannels();
		string[] names = new string[num];
		names = mr.GetChannelNames(); 

		SlidersCategory(cat1, "Body Evolution");
		SlidersCategory(cat2, "Victoria");
		SlidersCategory(cat3, "Body");
		SlidersCategory(cat4, "Abdomen");
		SlidersCategory(cat5, "Hip");
		SlidersCategory(cat6, "Arms");
		SlidersCategory(cat7, "Legs");
		SlidersCategory(cat8, "Face");
		SlidersCategory(cat9, "Breast");

		GUILayout.EndScrollView();
		GUILayout.EndArea();

		ResetAll(); // RESET ALL SLIDERS

	}

	/*=============================================
	              SLIDERS - CATEGORY
	==============================================*/
	void SlidersCategory(int[] arr, string mname)
	{
		// Num & Array names morphs channels  
		GUILayout.Label ("", labelStyle1);
		GUILayout.Label (mname, labelStyle2);
		GUILayout.Label ("", labelStyle3);
		
		MegaMorph mr = daz.GetComponent<MegaMorph>();
		int num = mr.NumChannels();
		string[] names = new string[num];
		names = mr.GetChannelNames(); 
		
		for (int i=0; i<num; i++) 
		{
			for (int j=0; j < arr.Length; j++) 
			{
				if (i == arr [j]) 
				{
					sliderValues [i] = TargetSlider (sliderValues [i], 100, names [i]);
					mr.SetPercent (i, sliderValues [i]);
				}
			}
		}
	}


	/*----------------------------
              ResetAll
	----------------------------*/
	public void ResetAll () 
	{
		if (GUI.Button (new Rect (30, Screen.height - 44, 190, 30), "RESET ALL")) 
		{
			// Num & Array names morphs channels  
			MegaMorph mr = daz.GetComponent<MegaMorph> ();
			int num = mr.NumChannels ();
			string[] names = new string[num];
			names = mr.GetChannelNames (); 
			
			for (int i=0; i<num; i++) {
				sliderValues [i] = TargetSlider (0, 100, names [i]);
				mr.SetPercent (i, 0);
			}
			
			//cam.GetComponent<MOrbit_SG> ().offset.y = 0;
			//cam.GetComponent<MOrbit_SG> ().offset.x = 0;
			//offsetSliderVert.value = 0;
			//offsetSliderHor.value = 0;
		}
	}

	/*-----------------------------
		      TargetSlider
	------------------------------*/
	float TargetSlider ( float sliderValue ,   float sliderMaxValue ,   string labelText  )
	{
		GUILayout.Label (labelText, labelStyle1);
		sliderValue = GUILayout.HorizontalSlider (sliderValue, 0.0f, sliderMaxValue);
		
		return sliderValue;
	}

}

/****************************************************
 * Screen.width
 * Screen.height 
 * *************************************************/
