﻿/*********************************************
  MorphSliders_ML.cs

  Writing by Sergey Gasanov, may,2015 
  version: 1.1
*********************************************/
using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class MorphSliders_ML : MonoBehaviour {

	public GameObject daz; 
	public int xPos = 25;
	public int yPos = 25;
	public int wide = 100;

	public Vector2 scrollPosition; 	// Position of the scrollview
	public GUISkin guiSkin;

	public GUIStyle labelStyle1; 	// Label Style for names morph channels
	public GUIStyle labelStyle2; 	// Label Style for NAME CATEOGORY
	public GUIStyle labelStyle3; 	// Label Style for SPACE LAGE

	//public Slider offsetSliderVert;	// Slider offset Vert
	//public Slider offsetSliderHor;	// Slider offset Hor
	//public Camera cam; 				// Main Camera

	private float[] sliderValues;


	/*----------------------------------- Category Channels ---------------------------------------*/
	// Category 1 - EVOLUTION
	private int[] cat1 = { 5, 6, 7, 49, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89 }; 				

	// Category 2 - MICHAEL
	private int[] cat2 = { 9, 10, 48, 0, 50, 51, 52, 53, 54, 55, 93 }; 				

	// Category 3 - BODY
	private int[] cat3 = { 1, 38, 39, 40, 41, 44, 71, 90 }; 

	// Category 4 - CHEST
	private int[] cat4 = { 63, 3, 8, 64, 65, 66, 67, 68, 69, 61 }; 

	// Category 5 - ABDOMEN
	private int[] cat5 = { 11, 12, 13, 14, 15, 16, 17, 18, 19, 30, 31, 32, 
		33, 34, 35, 36, 37, 43, 56, 58, 59, 60, 91, 20 }; 

	// Category 5 - HIP
	private int[] cat6 = { 22, 23, 24, 25, 26, 27, 28, 29, 70, 72, 73, 74, 75, 76 }; 

	// Category 6 - ARMS
	private int[] cat7 = { 2, 4, 42, 57, 62, 77, 92, 21 }; 


	// Category 8 - FACE
	private int[] cat8 = { 45, 46, 47 };


	void Awake () 
	{
		MegaMorph mr = daz.GetComponent<MegaMorph>();
		int num = mr.NumChannels();
		sliderValues = new float[num];
	}

	void Update ()
	{
	
	}

	/*=========== GUI ==========*/
	void  OnGUI ()
	{
		int i;

		GUI.skin = guiSkin; 	

		//GUI.Label (new Rect (10, 10, 100, 20), "Hello World!");

		GUILayout.BeginArea( new Rect(xPos, yPos, wide, Screen.height - 2*yPos));
		scrollPosition = GUILayout.BeginScrollView(scrollPosition);
		
		// Num & Array names morphs channels  
		MegaMorph mr = daz.GetComponent<MegaMorph>();
		int num = mr.NumChannels();
		string[] names = new string[num];
		names = mr.GetChannelNames(); 

		SlidersCategory(cat1, "Body Evolution"); 
		SlidersCategory(cat2, "Michael");
		SlidersCategory(cat3, "Body");
		SlidersCategory(cat4, "Chest");
		SlidersCategory(cat5, "Abdomen");
		SlidersCategory(cat6, "Hip");
		SlidersCategory(cat7, "Arms");
		SlidersCategory(cat8, "Face");

		GUILayout.EndScrollView();
		GUILayout.EndArea();

		ResetAll(); // RESET ALL SLIDERS

	}

	/*=============================================
	              SLIDERS - CATEGORY
	==============================================*/
	void SlidersCategory(int[] arr, string mname)
	{
		// Num & Array names morphs channels  
		GUILayout.Label ("", labelStyle1);
		GUILayout.Label (mname, labelStyle2);
		GUILayout.Label ("", labelStyle3);
		
		MegaMorph mr = daz.GetComponent<MegaMorph>();
		int num = mr.NumChannels();
		string[] names = new string[num];
		names = mr.GetChannelNames(); 
		
		for (int i=0; i<num; i++) 
		{
			for (int j=0; j < arr.Length; j++) 
			{
				if (i == arr [j]) 
				{
					sliderValues [i] = TargetSlider (sliderValues [i], 100, names [i]);
					mr.SetPercent (i, sliderValues [i]);
				}
			}
		}
	}


	/*----------------------------
              ResetAll
	----------------------------*/
	public void ResetAll () 
	{
		if (GUI.Button (new Rect (30, Screen.height - 44, 190, 30), "RESET ALL")) 
		{
			// Num & Array names morphs channels  
			MegaMorph mr = daz.GetComponent<MegaMorph> ();
			int num = mr.NumChannels ();
			string[] names = new string[num];
			names = mr.GetChannelNames (); 
			
			for (int i=0; i<num; i++) {
				sliderValues [i] = TargetSlider (0, 100, names [i]);
				mr.SetPercent (i, 0);
			}
			
			//cam.GetComponent<MOrbit_SG> ().offset.y = 0;
			//cam.GetComponent<MOrbit_SG> ().offset.x = 0;
			//offsetSliderVert.value = 0;
			//offsetSliderHor.value = 0;
		}
	}


	/*-----------------------------
		      TargetSlider
	------------------------------*/
	float TargetSlider ( float sliderValue ,   float sliderMaxValue ,   string labelText  )
	{
		GUILayout.Label (labelText, labelStyle1);
		sliderValue = GUILayout.HorizontalSlider (sliderValue, 0.0f, sliderMaxValue);

		return sliderValue;
	}

}
